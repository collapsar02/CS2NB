package weka.classifiers.bayes;

import weka.classifiers.AbstractClassifier;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;

import java.util.*;

public class CS2NB extends AbstractClassifier  {
    /** The number of each class value occurs in the dataset */
    private double[] m_ClassCounts;

    /** The number of each feature value occurs in the dataset */
    private double[] m_AttCounts;

    /** The number of two features values occurs in the dataset */
    private double[][] m_AttAttCounts;

    /** The number of class and two features values occurs in the dataset */
    private double[][][] m_ClassAttAttCounts;

    /** The number of values for each feature in the dataset */
    private int[] m_NumAttValues;

    /** The number of values for all features in the dataset */
    private int m_TotalAttValues;

    /** The number of classes in the dataset */
    private int m_NumClasses;

    /** The number of features including class in the dataset */
    private int m_NumAttributes;

    /** The number of instances in the dataset */
    private int m_NumInstances;

    /** The index of the class feature in the dataset */
    private int m_ClassIndex;

    /** The starting index of each feature in the dataset */
    private int[] m_StartAttIndex;

    /** The 2D array of the normalized mutual relevance to class for each feature */
    private double[][] m_mutualInformation;

    /** The array of the normalized correlation score for each unselected feature */
    private  double[] m_maraimarInformation;

    /** The 2D array of the feature value counts for each class. */
    private double[][] m_ClassAttCounts;

    /** The feature number of optimal feature subset */
    private int selectiveAttrNum;

    /** The selected subset */
    private List<Integer> selectedAttr = new ArrayList<>();

    /** The unselected subset */
    private List<Integer> unSelectAttr = new ArrayList<>();

    /** The normalized mutual redundancy */
    double[] aveMutualInfo;

    /** The test instance */
    private Instance TestInstance;

    /** The training instance */
    private Instances trainInstanes;

    /** The average posterior probability */
    double[] aveProbility;

    /** The map of the selected feature indices for each round. */
    private Map<Integer,List<Integer>> map = new HashMap<>();


    /** The intermediate variable */
    private List<Integer> originalAttr = new ArrayList<>();
    private double totalWeightFirst;
    private double totalWeight;


    /**
     * Generates the classifier.
     *
     * @param instances
     *            set of instances serving as training data
     * @exception Exception
     *                if the classifier has not been generated successfully
     */
    public void buildClassifier(Instances instances) throws Exception {
        long startTime = System.nanoTime();
        String datasetName = instances.relationName();
        trainInstanes = instances;
        // Reset variable
        m_NumClasses = instances.numClasses();
        m_ClassIndex = instances.classIndex();
        m_NumAttributes = instances.numAttributes();
        m_NumInstances = instances.numInstances();
        m_TotalAttValues = 0;

        // Allocate space for attribute reference arrays
        m_StartAttIndex = new int[m_NumAttributes];
        m_NumAttValues = new int[m_NumAttributes];

        // Set the starting index of each feature and the number of values for
        // each feature and the total number of values for all attributes (not
        // including class).
        for (int i = 0; i < m_NumAttributes; i++) {
            m_StartAttIndex[i] = m_TotalAttValues;
            m_NumAttValues[i] = instances.attribute(i).numValues();
            m_TotalAttValues += m_NumAttValues[i];
        }

        // Allocate space for counts and frequencies
        m_ClassCounts = new double[m_NumClasses];
        m_AttCounts = new double[m_TotalAttValues];
        m_AttAttCounts = new double[m_TotalAttValues][m_TotalAttValues];
        m_ClassAttAttCounts = new double[m_NumClasses][m_TotalAttValues][m_TotalAttValues];
        m_ClassAttCounts = new double[m_NumClasses][m_TotalAttValues];
        m_mutualInformation = new double[m_NumAttributes][m_NumAttributes];


        // Calculate the counts
        for (int k = 0; k < m_NumInstances; k++) {
            int classVal = (int) instances.instance(k).classValue();
            m_ClassCounts[classVal]++;
            int[] attIndex = new int[m_NumAttributes];
            for (int i = 0; i < m_NumAttributes; i++) {
                if(instances.instance(k).isMissing(i)) {
                    continue;
                }
                attIndex[i] = m_StartAttIndex[i] + (int) instances.instance(k).value(i);
                m_AttCounts[attIndex[i]]++;
                m_ClassAttCounts[classVal][attIndex[i]]++;
            }
            for (int Att1 = 0; Att1 < m_NumAttributes; Att1++) {
                for (int Att2 = 0; Att2 < m_NumAttributes; Att2++) {
                    m_AttAttCounts[attIndex[Att1]][attIndex[Att2]]++;
                    m_ClassAttAttCounts[classVal][attIndex[Att1]][attIndex[Att2]]++;
                }
            }
        }
        // Compute normalized mutual relevance between each feature and the class
        CalculatemutualInfo();
        // Conduct feature ranking and subset selection
        selectFeature();
        long endTime = System.nanoTime();
        double  duration = (endTime - startTime) / 1_000_000.0; // 单位：ms
        // 输出到 CSV
//        writeTimeToConsole(datasetName,"CS2NB",duration);
    }
    private void writeTimeToConsole(String datasetName, String classifierName, double duration) {
        // 输出到控制台，格式：算法名 数据集名 时间(ms)
        System.out.println(classifierName + " " + datasetName + " " + duration);
    }




    private void selectFeature() throws Exception {
        //Perform feature ranking and subset selection log m times
        for(int times=0;times<Math.log(m_NumAttributes-1)/Math.log(2);times++){
            for(int i=0;i<m_NumAttributes-1;i++){
                unSelectAttr.add(i);
            }
            selectedAttr.clear();
            //Feature ranking
            while (selectedAttr.size() < m_NumAttributes - 1) {
                //Select the first-ranked feature
                originalAttr.clear();
                if (selectedAttr.size() == 0) {
                    totalWeightFirst=0;
                    double[][] sortedMutualInformation = new double[m_mutualInformation.length][2];
                    sortArrayByColumn(m_mutualInformation, sortedMutualInformation);
                    //Roulette Wheel Selection
                    for(int i=0;i<Math.log(unSelectAttr.size()) / Math.log(2);i++){
                        totalWeightFirst += sortedMutualInformation[i][1];
                    }
                    double randomValue = new Random().nextDouble() * totalWeightFirst;
                    double cumulativeProbability = 0.0;
                    for (int i = 0; i < originalAttr.size(); i++) {
                        cumulativeProbability += m_mutualInformation[originalAttr.get(i)][m_ClassIndex];
                        if (randomValue <= cumulativeProbability) {
                            int index = originalAttr.get(i);
                            selectedAttr.add(index);
                            unSelectAttr.remove(Integer.valueOf(index));
                            break;
                        }
                    }
                }
                //Select the remaining-ranked feature
                else {
                    aveMutualInfo = new double[m_NumAttributes];
                    totalWeight=0;
                    m_maraimarInformation= new double[m_NumAttributes-1];
                    //Calculate normalized mutual redundancy between each unselected feature and selected feature
                    CalculateRedundancy(aveMutualInfo);
                    //Calculate normalized correlation score
                    for(int att1=0; att1<unSelectAttr.size(); att1++){
                        int att1_index = unSelectAttr.get(att1);
                        m_maraimarInformation[att1_index]=1 / (1 + Math.exp(-(m_mutualInformation[att1_index][m_ClassIndex]-aveMutualInfo[att1_index])));
                    }
                    //Handle the number of nodes in the min-heap
                    double n=0;
                    if(Math.log(unSelectAttr.size()) / Math.log(2)!=0){
                        n= Math.log(unSelectAttr.size()) / Math.log(2);
                    }else{
                        n=1;
                    }
                    //Use a min-heap to select the top-ranked features
                    printTopNIndices(m_maraimarInformation,n);

                    //Roulette Wheel Selection
                    for(int att1=0; att1<originalAttr.size(); att1++){
                        int att1_index = originalAttr.get(att1);
                        totalWeight += m_maraimarInformation[att1_index];
                    }
                    double randomValue = new Random().nextDouble() * totalWeight;
                    double cumulativeProbability = 0.0;
                    for (int i = 0; i < originalAttr.size(); i++) {
                        int att1_index = originalAttr.get(i);
                        cumulativeProbability += m_maraimarInformation[att1_index];
                        if (randomValue <= cumulativeProbability) {
                            int index = originalAttr.get(i);
                            m_maraimarInformation[index]=-100;
                            selectedAttr.add(index);
                            unSelectAttr.remove(Integer.valueOf(index));
                            break;
                        }
                    }
                    m_maraimarInformation=null;

                }
            }


            //Subset selection by LOOCV
            double[] leaveOneOutResult = new double[m_NumAttributes-1];
            for (int k = 0; k < m_NumInstances; k++) {
                int classVal = (int) trainInstanes.instance(k).classValue();
                m_ClassCounts[classVal]--;
                int[] attIndex = new int[m_NumAttributes];
                for (int i = 0; i < m_NumAttributes; i++) {
                    if(trainInstanes.instance(k).isMissing(i)) {
                        continue;
                    }
                    attIndex[i] = m_StartAttIndex[i] + (int) trainInstanes.instance(k).value(i);
                    m_AttCounts[attIndex[i]]--;
                    m_ClassAttCounts[classVal][attIndex[i]]--;
                }
                for (int i = 0; i < m_NumAttributes; i++) {
                    for (int j = 0; j < m_NumAttributes; j++) {
                        m_AttAttCounts[attIndex[i]][attIndex[j]]--;
                    }
                }
                double[] probs = new double[m_NumClasses];
                int[] attIndex_tmp = new int[m_NumAttributes];
                for (int att = 0; att < m_NumAttributes; att++) {
                    if (att == m_ClassIndex)
                        attIndex_tmp[att] = -1;
                    else
                        attIndex_tmp[att] = m_StartAttIndex[att] + (int) trainInstanes.instance(k).value(att);
                }
                for (int classVal1 = 0; classVal1 < m_NumClasses; classVal1++) {
                    probs[classVal1] = (m_ClassCounts[classVal1] + 1.0/m_NumClasses) / (m_NumInstances + 1.0);
                }
                for (int att1 = 0; att1 < m_NumAttributes-1; att1++) {
                    int attIndex1 = selectedAttr.get(att1);
                    double max = 0;
                    if (attIndex[attIndex1] == -1)
                        continue;
                    if (trainInstanes.instance(k).isMissing(attIndex1)) {
                        continue;
                    }
                    for (int classVal1 = 0; classVal1 < m_NumClasses; classVal1++) {
                        probs[classVal1] *= (m_ClassAttCounts[classVal1][attIndex[attIndex1]] + 1.0/m_NumAttValues[attIndex1])
                                / (m_ClassCounts[classVal1] + 1.0);
                        if (probs[classVal1] > max) {
                            max = probs[classVal1];
                        }
                        if ((max > 0) && (max < 1e-75)) { // Danger of probability underflow
                            for (int j = 0; j < m_NumClasses; j++) {
                                probs[j] *= 1e75;
                            }
                        }
                    }
                    double[] probs2 = new double[m_NumClasses];
                    double sumProb = 0;
                    for(int x=0; x<m_NumClasses; x++){
                        probs2[x] = probs[x];
                        sumProb += probs[x];
                    }
                    for(int x=0; x<m_NumClasses; x++){
                        probs2[x] = probs2[x]/sumProb;
                    }
                    double p = probs2[(int) trainInstanes.instance(k).classValue()];
                    leaveOneOutResult[att1] += Math.pow(1-p, 2.0);
                }
                m_ClassCounts[classVal]++;
                for (int i = 0; i < m_NumAttributes; i++) {
                    // skip the missing values
                    if(trainInstanes.instance(k).isMissing(i)) {
                        continue;
                    }
                    attIndex[i] = m_StartAttIndex[i] + (int) trainInstanes.instance(k).value(i);
                    m_AttCounts[attIndex[i]]++;
                    m_ClassAttCounts[classVal][attIndex[i]]++;
                }

                for (int i = 0; i < m_NumAttributes; i++) {
                    for (int j = 0; j < m_NumAttributes; j++) {
                        m_AttAttCounts[attIndex[i]][attIndex[j]]++;
                    }
                }

            }
            // Find the subset with minimum RMSE as optimal selective subset
            double minimum = leaveOneOutResult[0];
            int minimumPos = 0;
            for(int i=0; i<leaveOneOutResult.length; i++){
                if(leaveOneOutResult[i]<minimum){
                    minimum = leaveOneOutResult[i];
                    minimumPos = i;
                }
            }
            selectiveAttrNum = minimumPos;
            List<Integer> list = new ArrayList<>();
            for(int i=0;i<=selectiveAttrNum;i++){
                list.add(selectedAttr.get(i));
            }
            map.put(times, list);
        }

    }

    /**
     * Calculate the class membership probabilities for the given test instance
     *
     * @param instance
     *            the instance to be classified
     * @return predicted class probability distribution
     * @exception Exception
     *                if there is a problem generating the prediction
     */
    public double[] distributionForInstance(Instance instance) throws Exception {
        TestInstance = instance;
        return prob();
    }

    /**Calculate the average posterior probability */
    private double[] prob() throws Exception {
        aveProbility = new double[m_NumClasses];
        int times;
        for(times=0 ;times<Math.log(m_NumAttributes-1)/Math.log(2);times++){
            double[] prob = distributionForInstanceByTimes(TestInstance,times);
            for(int numClass = 0; numClass < m_NumClasses; numClass++){
                aveProbility[numClass] += prob[numClass];
            }
        }
        for(int numClass = 0; numClass < m_NumClasses; numClass++){
            aveProbility[numClass] /= times;
        }
        return aveProbility;
    }

    /** Calculate the class Posterior probability for the given test instance and iteration */
    public double[] distributionForInstanceByTimes(Instance instance,int times) throws Exception {
        double[] probs = new double[m_NumClasses];
        int[] attIndex = new int[m_NumAttributes];
        for (int att = 0; att < m_NumAttributes; att++) {
            if (att == m_ClassIndex)
                attIndex[att] = -1;
            else
                attIndex[att] = m_StartAttIndex[att] + (int) instance.value(att);
        }

        for (int classVal = 0; classVal < m_NumClasses; classVal++) {
            probs[classVal] = (m_ClassCounts[classVal] + 1.0/m_NumClasses) / (m_NumInstances + 1.0);
        }

        for (int att1 = 0; att1 < map.get(times).size(); att1++) {
            int attIndex1 = (int)map.get(times).get(att1);
            double max = 0;
            if (attIndex[attIndex1] == -1)
                continue;
            if (instance.isMissing(attIndex1)) {
                continue;
            }
            // calculate probabilities for each possible class value
            for (int classVal1 = 0; classVal1 < m_NumClasses; classVal1++) {

                probs[classVal1] *= (m_ClassAttCounts[classVal1][attIndex[attIndex1]] + 1.0/m_NumAttValues[attIndex1])
                        / (m_ClassCounts[classVal1] + 1.0);


                if (probs[classVal1] > max) {
                    max = probs[classVal1];
                }

                if ((max > 0) && (max < 1e-75)) { // Danger of probability underflow
                    for (int j = 0; j < m_NumClasses; j++) {
                        probs[j] *= 1e75;
                    }
                }
            }
        }
        Utils.normalize(probs);
        return probs;
    }



    /**Sorting method */
    private void sortArrayByColumn(double[][] originalData, double[][] sortedData) {
        for(int i=0;i<m_mutualInformation.length;i++){
            sortedData[i][0] = i;
            sortedData[i][1] = m_mutualInformation[i][m_ClassIndex];
        }

        Arrays.sort(sortedData, new Comparator<double[]>() {
            @Override
            public int compare(double[] o1, double[] o2) {

                if (o1[1] > o2[1]) {
                    return -1;
                } else if (o1[1] < o2[1]) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });

        for (int i = 0; i < Math.log(unSelectAttr.size()) / Math.log(2) ; i++) {
            originalAttr.add((int) sortedData[i][0]);
        }
    }

    /**min-heap */
    public void printTopNIndices(double[] arr, double n) {
        if (arr == null || n <= 0 || n > arr.length) {
            System.out.println("Invalid input");
            return;
        }

        PriorityQueue<double[]> minHeap = new PriorityQueue<>(Comparator.comparingDouble(a -> a[0]));

        for (int i = 0; i < arr.length; i++) {

            if (minHeap.size() < n) {
                minHeap.offer(new double[]{arr[i], i});
            } else {

                if (arr[i] > minHeap.peek()[0]) {
                    minHeap.poll();
                    minHeap.offer(new double[]{arr[i], i});
                }
            }
        }


        while (!minHeap.isEmpty()) {
            double[] pair = minHeap.poll();
            originalAttr.add((int)pair[1]);
        }
    }


    /** Calculate normalized mutual relevance*/
    private void CalculatemutualInfo() throws Exception {
        for (int att1 = 0; att1 < m_NumAttributes-1; att1++) {
            m_mutualInformation[att1][m_ClassIndex] = mutualInfo(att1, m_ClassIndex);
//            m_mutualInformation[m_ClassIndex][att1] = m_mutualInformation[att1][m_ClassIndex];
        }
        double ave = 0;
        for (int att1 = 0; att1 < m_NumAttributes; att1++) {
            if (att1 == m_ClassIndex)
                continue;
            ave += m_mutualInformation[att1][m_ClassIndex];
        }
        ave /= (m_NumAttributes - 1);
        for (int att1 = 0; att1 < m_NumAttributes; att1++) {
            if (att1 == m_ClassIndex)
                continue;
            m_mutualInformation[att1][m_ClassIndex] /= ave;
//            m_mutualInformation[m_ClassIndex][att1] = m_mutualInformation[att1][m_ClassIndex];
        }
    }

    /** Calculate normalized mutual redudancy*/
    private void  CalculateRedundancy(double[] aveMutualInfo) throws Exception {
        double mean=0;
        for(int att1 = 0;att1<unSelectAttr.size();att1++){
            for(int att2 =0;att2<selectedAttr.size();att2++){
                int att1_index = unSelectAttr.get(att1);
                int att2_index = selectedAttr.get(att2);
                m_mutualInformation[att1_index][att2_index] = mutualInfo(att1_index,att2_index);
                mean += m_mutualInformation[att1_index][att2_index];
            }
        }
        mean /= (unSelectAttr.size()* selectedAttr.size());
        for (int att1 = 0; att1 <unSelectAttr.size(); att1++) {
            for (int att2 = 0; att2 <selectedAttr.size(); att2++) {
                int att1_index = unSelectAttr.get(att1);
                int att2_index = selectedAttr.get(att2);
                m_mutualInformation[att1_index][att2_index] = chu(m_mutualInformation[att1_index][att2_index],mean);
            }
        }
        double weightSum = (double) selectedAttr.size() * (selectedAttr.size() + 1) / 2.0;
        for (int att1 = 0; att1 < unSelectAttr.size(); att1++) {
            for (int att2 = 0; att2 < selectedAttr.size(); att2++) {
                int att1_index = unSelectAttr.get(att1);
                int att2_index = selectedAttr.get(att2);
                double weight = (selectedAttr.size() - att2) / weightSum;
                aveMutualInfo[att1_index] += weight * m_mutualInformation[att1_index][att2_index];
            }
//            aveMutualInfo[unSelectAttr.get(att1)] /= selectedAttr.size();
        }
    }

    /** calculate mutual information */
    private double mutualInfo(int att1, int att2) throws Exception {

        double mutualInfo = 0;
        int attIndex1 = m_StartAttIndex[att1];
        int attIndex2 = m_StartAttIndex[att2];
        double[] PriorsAtt1 = new double[m_NumAttValues[att1]];
        double[] PriorsAtt2 = new double[m_NumAttValues[att2]];
        double[][] PriorsAtt1Att2 = new double[m_NumAttValues[att1]][m_NumAttValues[att2]];

        for (int i = 0; i < m_NumAttValues[att1]; i++) {
            PriorsAtt1[i] = m_AttCounts[attIndex1 + i] / m_NumInstances;
        }

        for (int j = 0; j < m_NumAttValues[att2]; j++) {
            PriorsAtt2[j] = m_AttCounts[attIndex2 + j] / m_NumInstances;
        }

        for (int i = 0; i < m_NumAttValues[att1]; i++) {
            for (int j = 0; j < m_NumAttValues[att2]; j++) {
                PriorsAtt1Att2[i][j] = m_AttAttCounts[attIndex1 + i][attIndex2 + j] / m_NumInstances;
            }
        }

        for (int i = 0; i < m_NumAttValues[att1]; i++) {
            for (int j = 0; j < m_NumAttValues[att2]; j++) {
                mutualInfo += PriorsAtt1Att2[i][j] * log2(PriorsAtt1Att2[i][j], PriorsAtt1[i] * PriorsAtt2[j]);
            }
        }
        return mutualInfo;
    }

    private double chu(double x,double y){
        if (x < 1e-6 || y < 1e-6)
            return 0.0;
        else
            return x/y;
    }

    private double log2(double x, double y) {

        if (x < 1e-6 || y < 1e-6)
            return 0.0;
        else
            return Math.log(x / y) / Math.log(2);
    }

}
