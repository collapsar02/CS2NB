The detailed processes of using the code  (WEKA 3.8.6) :
1.Put CS2NB.java into directory: weka.classifiers.bayes
2.Run WEKA, choose Experimenter/Explorer window, add the datasets, choose bayes.CS2NB model, then click "start".
